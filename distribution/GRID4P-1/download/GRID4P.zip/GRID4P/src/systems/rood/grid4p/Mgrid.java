package systems.rood.grid4p;

//The Mgrid class is deprecated, we're keeping it around for compatibility purposes.
public class Mgrid extends Grid{
    Mgrid(){
        super();
    }
}
