package grid4p;

//The Mknob class is deprecated, we're keeping it around for compatibility purposes.
public class Mknob extends Gknob{
    Mknob(){
        super();
    }
}
