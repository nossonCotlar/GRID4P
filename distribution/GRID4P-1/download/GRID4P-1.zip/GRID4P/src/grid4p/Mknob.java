package grid4p;

/**
 * We're keeping this around for compatibility. Don't use it.
 * @deprecated
 */
//The Mknob class is deprecated, we're keeping it around for compatibility purposes.
public class Mknob extends Gknob{
    Mknob(){
        super();
    }
}
